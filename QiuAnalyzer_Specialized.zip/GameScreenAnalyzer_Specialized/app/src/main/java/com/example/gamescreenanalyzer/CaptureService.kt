package com.example.gamescreenanalyzer

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class CaptureService : Service() {
    companion object {
        const val ACTION_RESULT="com.example.gamescreenanalyzer.RESULT"
        const val EXTRA_RESULT_CODE="result_code"; const val EXTRA_RESULT_DATA="result_data"
        const val EXTRA_DASH="dash"; const val EXTRA_HISTORY="history"
        private const val CHANNEL="analyzer"; private const val NOTIFY=7
    }
    private lateinit var projection: MediaProjection
    private lateinit var reader: ImageReader
    private var display: VirtualDisplay?=null
    private val handler=Handler(Looper.getMainLooper())
    private val ocr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy=false; private var lastSig=""; private var rounds=0
    private val history=mutableListOf<String>()

    override fun onCreate(){ super.onCreate(); createChannel(); startForeground(NOTIFY, NotificationCompat.Builder(this,CHANNEL).setContentTitle("Game Screen Analyzer").setContentText("Menganalisis layar game").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()) }
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        val code=i?.getIntExtra(EXTRA_RESULT_CODE,-1)?:-1
        val data=i?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)?:return START_NOT_STICKY
        if(code<0)return START_NOT_STICKY
        val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=pm.getMediaProjection(code,data); setup(); return START_NOT_STICKY
    }
    private fun setup(){
        val m=resources.displayMetrics; val w=m.widthPixels; val h=m.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        display=projection.createVirtualDisplay("GameAnalyzer",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.surface,null,handler)
        handler.post(loop)
    }
    private val loop=object:Runnable{override fun run(){ frame(); handler.postDelayed(this,900)}}
    private fun frame(){
        if(busy)return; val image=reader.acquireLatestImage()?:return; busy=true
        val p=image.planes[0]; val buf=p.buffer; val rowPadding=p.rowStride-p.pixelStride*image.width
        val bmp=Bitmap.createBitmap(image.width+rowPadding/p.pixelStride,image.height,Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(buf); image.close()
        // First OCR the two score ROIs using proportional crops.
        val red=crop(bmp,.27f,.48f,.36f,.60f); val blue=crop(bmp,.64f,.48f,.73f,.60f); val trend=crop(bmp,.80f,.00f,1f,1f)
        val tasks=listOf(InputImage.fromBitmap(red,0),InputImage.fromBitmap(blue,0),InputImage.fromBitmap(trend,0))
        val texts=ArrayList<String>(); var done=0
        for((idx,input) in tasks.withIndex()){
            ocr.process(input).addOnSuccessListener{r-> synchronized(texts){ while(texts.size<=idx)texts.add(""); texts[idx]=r.text; done++; if(done==3)finishFrame(bmp,red,blue,trend,texts)} }.addOnFailureListener{ synchronized(texts){while(texts.size<=idx)texts.add(""); texts[idx]=""; done++; if(done==3)finishFrame(bmp,red,blue,trend,texts)}}
        }
    }
    private fun finishFrame(full:Bitmap,red:Bitmap,blue:Bitmap,trend:Bitmap,texts:List<String>){
        val r=parseScore(texts.getOrNull(0).orEmpty()); val b=parseScore(texts.getOrNull(1).orEmpty())
        val sig="${r}|${b}|${texts.getOrNull(0)}|${texts.getOrNull(1)}"
        if(sig!=lastSig && (r!=null||b!=null)){
            lastSig=sig; rounds++; history.add("Ronde $rounds  •  Mer: ${r?:"?"}  Biru: ${b?:"?"}")
            val dash="Ronde $rounds\nMerah/Qiu: ${r?:"?"}\nBiru: ${b?:"?"}\n\nTrend (OCR):\n${texts.getOrNull(2).orEmpty().take(500)}"
            send(dash,history.takeLast(20).reversed().joinToString("\n"))
        }
        red.recycle();blue.recycle();trend.recycle();full.recycle();busy=false
    }
    private fun parseScore(s:String):Int?{ val nums=Regex("\\b([0-9])\\b").findAll(s).map{it.groupValues[1].toInt()}.toList(); return nums.firstOrNull() }
    private fun crop(src:Bitmap,l:Float,t:Float,r:Float,b:Float):Bitmap{val x=(src.width*l).toInt().coerceIn(0,src.width-1);val y=(src.height*t).toInt().coerceIn(0,src.height-1);val w=((src.width*(r-l)).toInt()).coerceAtLeast(1).coerceAtMost(src.width-x);val h=((src.height*(b-t)).toInt()).coerceAtLeast(1).coerceAtMost(src.height-y);return Bitmap.createBitmap(src,x,y,w,h)}
    private fun send(dash:String,hist:String){sendBroadcast(Intent(ACTION_RESULT).setPackage(packageName).putExtra(EXTRA_DASH,dash).putExtra(EXTRA_HISTORY,hist))}
    private fun createChannel(){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Screen Analyzer",NotificationManager.IMPORTANCE_LOW))}
    override fun onDestroy(){handler.removeCallbacksAndMessages(null);display?.release();if(::reader.isInitialized)reader.close();if(::projection.isInitialized)projection.stop();ocr.close();super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
