package com.example.gamescreenanalyzer

import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
    private val code=1001; private lateinit var start:Button; private lateinit var stop:Button; private lateinit var dash:TextView; private lateinit var hist:TextView
    private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){if(i?.action!=CaptureService.ACTION_RESULT)return;dash.text=i.getStringExtra(CaptureService.EXTRA_DASH)?:("Belum ada hasil");hist.text=i.getStringExtra(CaptureService.EXTRA_HISTORY)?:("Belum ada histori")}}
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);start=findViewById(R.id.startButton);stop=findViewById(R.id.stopButton);dash=findViewById(R.id.dashboard);hist=findViewById(R.id.history)
        start.setOnClickListener{val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;startActivityForResult(pm.createScreenCaptureIntent(),code)}
        stop.setOnClickListener{stopService(Intent(this,CaptureService::class.java));running(false)} }
    private fun running(v:Boolean){start.isEnabled=!v;stop.isEnabled=v}
    override fun onActivityResult(r:Int,result:Int,data:Intent?){super.onActivityResult(r,result,data);if(r==code&&result==Activity.RESULT_OK&&data!=null){startForegroundService(Intent(this,CaptureService::class.java).putExtra(CaptureService.EXTRA_RESULT_CODE,result).putExtra(CaptureService.EXTRA_RESULT_DATA,data));running(true)}}
    override fun onStart(){super.onStart();registerReceiver(receiver,IntentFilter(CaptureService.ACTION_RESULT),RECEIVER_NOT_EXPORTED)}
    override fun onStop(){unregisterReceiver(receiver);super.onStop()}
}
