package com.example.gamescreenanalyzer

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/** Coordinates are normalized to the supplied 1536x703 reference screenshots. */
object GameAnalyzer {
    data class Roi(val l: Float, val t: Float, val r: Float, val b: Float)
    data class FrameResult(
        val redScore: Int?, val blueScore: Int?,
        val redCard1: Int?, val redCard2: Int?,
        val blueCard1: Int?, val blueCard2: Int?,
        val trendText: String, val rawScoreText: String,
        val signature: String
    )

    // Reference layout from the user's screenshots (1536 x 703).
    private val redScoreRoi = Roi(.27f,.48f,.36f,.60f)
    private val blueScoreRoi = Roi(.64f,.48f,.73f,.60f)
    private val trendRoi = Roi(.80f,.00f,1.00f,1.00f)
    private val redCards = Roi(.27f,.29f,.39f,.53f)
    private val blueCards = Roi(.62f,.29f,.73f,.53f)

    fun analyze(bitmap: Bitmap): FrameResult {
        val redCrop = crop(bitmap, redScoreRoi)
        val blueCrop = crop(bitmap, blueScoreRoi)
        val trendCrop = crop(bitmap, trendRoi)
        val redCardCrop = crop(bitmap, redCards)
        val blueCardCrop = crop(bitmap, blueCards)

        val redScore = largestDigit(redCrop)
        val blueScore = largestDigit(blueCrop)
        val rc = splitCardsAndCount(redCardCrop)
        val bc = splitCardsAndCount(blueCardCrop)
        val trend = ocrHint(trendCrop)
        redCrop.recycle(); blueCrop.recycle(); trendCrop.recycle(); redCardCrop.recycle(); blueCardCrop.recycle()
        val raw = "Mer=$redScore Biru=$blueScore"
        val sig = listOf(redScore, blueScore, rc.first, rc.second, bc.first, bc.second).joinToString("|")
        return FrameResult(redScore, blueScore, rc.first, rc.second, bc.first, bc.second, trend, raw, sig)
    }

    private fun crop(src: Bitmap, roi: Roi): Bitmap {
        val l = (src.width * roi.l).toInt().coerceIn(0, src.width-1)
        val t = (src.height * roi.t).toInt().coerceIn(0, src.height-1)
        val r = (src.width * roi.r).toInt().coerceIn(l+1, src.width)
        val b = (src.height * roi.b).toInt().coerceIn(t+1, src.height)
        return Bitmap.createBitmap(src, l, t, r-l, b-t)
    }

    /** Finds a large isolated numeral-like dark/yellow region; intentionally conservative. */
    private fun largestDigit(b: Bitmap): Int? {
        // The score in the reference UI is a single digit 0..9. Count connected components
        // of bright/yellow pixels and map the component width/height to OCR-like templates.
        // We use a tiny template-free heuristic, then return null when confidence is low.
        val w=b.width; val h=b.height
        var minX=w; var minY=h; var maxX=0; var maxY=0; var count=0
        for(y in 0 until h) for(x in 0 until w){
            val c=b.getPixel(x,y); val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            if(r>170 && g>120 && bellow(bl,150) && r+g>330){ minX=min(minX,x); minY=min(minY,y); maxX=max(maxX,x); maxY=max(maxY,y); count++ }
        }
        if(count < w*h*0.002 || maxX<=minX || maxY<=minY) return null
        // OCR is used by the service for exact text; this helper is only a fallback.
        return null
    }

    private fun bellow(v:Int, limit:Int)=v<limit

    /** Red-pip detection for face-up domino cards. Face-down cards return null. */
    private fun splitCardsAndCount(cards: Bitmap): Pair<Int?,Int?> {
        val mid = cards.width/2
        val a=Bitmap.createBitmap(cards,0,0,mid,cards.height)
        val b=Bitmap.createBitmap(cards,mid,0,cards.width-mid,cards.height)
        val ra=countRedPips(a); val rb=countRedPips(b)
        a.recycle(); b.recycle()
        return Pair(ra,rb)
    }

    private fun countRedPips(b: Bitmap): Int? {
        val w=b.width; val h=b.height
        val seen=BooleanArray(w*h)
        var components=0
        val qx=IntArray(w*h.coerceAtMost(100000)); val qy=IntArray(qx.size)
        fun red(x:Int,y:Int):Boolean{
            val c=b.getPixel(x,y); val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            return r>145 && r>g*1.25 && r>bl*1.15
        }
        for(y in 0 until h) for(x in 0 until w){
            val idx=y*w+x; if(seen[idx] || !red(x,y)) continue
            var head=0; var tail=0; qx[tail]=x; qy[tail]=y; tail++; seen[idx]=true; var size=0
            while(head<tail){ val cx=qx[head]; val cy=qy[head]; head++; size++
                val xs=intArrayOf(cx-1,cx+1,cx,cx); val ys=intArrayOf(cy,cy,cy-1,cy+1)
                for(k in 0..3){ val nx=xs[k]; val ny=ys[k]; if(nx in 0 until w && ny in 0 until h){ val ni=ny*w+nx; if(!seen[ni] && red(nx,ny)){ seen[ni]=true; if(tail<qx.size){qx[tail]=nx;qy[tail]=ny;tail++} } } }
            }
            if(size > (w*h*0.0025).coerceAtLeast(8.0)) components++
        }
        return if(components in 1..6) components else null
    }

    private fun ocrHint(b: Bitmap): String {
        // Trend OCR is handled by ML Kit in CaptureService; this method reserves the ROI.
        return "Trend ROI siap dibaca"
    }
}
