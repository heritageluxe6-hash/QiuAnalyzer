# Qiu Analyzer — Specialized Android Prototype

Versi ini disesuaikan dengan dua screenshot 1536x703 yang diberikan pengguna.

## Yang dibaca
- ROI skor Merah/Qiu
- ROI skor Biru
- ROI panel Trend kanan
- Deteksi perubahan ronde berdasarkan hasil OCR
- Histori sampai 20 ronde terakhir di layar aplikasi

## Cara menjalankan
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync.
3. Build > Build APK(s).
4. Install APK pada HP Android.
5. Buka aplikasi > Mulai Analisis Layar > izinkan screen capture.
6. Buka game dalam orientasi landscape dan biarkan analyzer berjalan.

## Catatan penting
Preset ROI mengikuti screenshot referensi 1536x703. Jika resolusi/aspect ratio game berbeda, koordinat ROI mungkin perlu dikalibrasi. Versi ini menganalisis output yang terlihat; bukan algoritma internal/server game dan bukan prediktor hasil pasti.
